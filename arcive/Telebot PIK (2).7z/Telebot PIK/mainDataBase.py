import sqlite3

with sqlite3.connect('data.db',  check_same_thread=False) as db:
    cursor = db.cursor()

    #cursor.execute("""DROP TABLE IF EXISTS services""")
    #Потом удалится, взаимодействие с базой через приложение DB Browser

'''
    test = cursor.execute("""SELECT services.text, program.program_name FROM services INNER JOIN
    Program ON services.id = program.service_id
    WHERE service_id=1;
    """)
    for item in test:
        print(item)
'''
def getData(table):
    data = []
    dataList = cursor.execute(f"""SELECT * FROM {table}""")
    for item in dataList:
        data.append(item)
    return data

def getSelectedData(firstData, secondData, id):
    test = cursor.execute(f"""SELECT {firstData}.text, {secondData}.program_name FROM services INNER JOIN
      Program ON {firstData}.id = {secondData}.syptoms_id
      WHERE syptoms_id={id};
      """)
    return



