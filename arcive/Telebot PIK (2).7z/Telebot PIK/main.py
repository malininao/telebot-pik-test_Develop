import telebot
from telebot import types
import telebot
from telebot.types import Message
from config import TOKEN
from mainDataBase import getData

#не забуд прописать в терминал команду pip install pytelegrambotapi (если у тебя мак то pip3, а не pip)

bot = telebot.TeleBot(TOKEN)
#Подключаем данные из БД

data = getData('t1')

#это глвное меню бота (вызывается из базы данных, формируется на основе ее значений)
@bot.message_handler(commands=['start'])
def start(message):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1) #переменная вызывает клавиатуру
    itembtn = types.KeyboardButton('СТАРТ')
    markup.add(itembtn)
    bot.send_message(message.chat.id,'Что может делать этот бот ?'+'\n'+''+'\n'
    'Бот помощник Osipia 👷 - Ваш персональный BIM - помощник.'+'\n'
    '🛠 Решение проблем в работе ПО.'+'\n'+
    '🔍 Навигация и поиск по учебным материалам.'+'\n'
    '📚 Полезные ссылки и материалы.')
    msg = bot.send_message(message.chat.id,
                           'Привет, ' + message.from_user.first_name + ', нажми СТАРТ',
                           reply_markup=markup) #вызвать клаву
    bot.register_next_step_handler(msg, main_menu_select_step, data)


#функция заполняет клавиатуру которая генерируется из базы данных (только главное меню)
def main_menu_select_step(message, data):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)  # переменная вызывает клавиатуру
    messageList = []

    for item in data:
        itembtn = types.KeyboardButton(item[1])
        messageList.append(str(item[4]))
        markup.add(itembtn)
    msg = bot.send_message(message.chat.id,
                           messageList[0],
                           reply_markup=markup)  # вызвать клаву
    bot.register_next_step_handler(msg, process_select_step, data)


#выбор дальнейших шагов в по таблицам БД
def process_select_step(message, data):
    try:
        #пустые массивы в начале функций нужны для того что при каждом вызове функции из значения заполнялись заново
        nextStep = []
        texts = []
        lastStep = []
        firstTable = 't1'
        for item in data: #пробег по массиву из кортежей, получаем следующую т
            # аблицу, текст кнопок, и предыдущую таблицу

            texts.append(item[1])
            nextStep.append(str(item[2]))
            lastStep.append(str(item[3]))
            print(item[1],"->", item[2])

        if message.text == "В НАЧАЛО" or message.text == "Ок": #откатываемся в главное меню
            data = getData(firstTable)
            main_menu_select_step(message, data)

        elif nextStep[1]=="t01": #если следующая таблица пустая то вызывается
            # функция в которой выводится текст инструкции

            instructionList=[]
            for item in data:
                instructionList.append(item[5])
            index = texts.index(message.text)
            instruction = instructionList[index]
            print_instruction_step(message, instruction)

        else:#в любом другом случае получаем данные о дальнейшем и предыдущем шаге
            # для вызова шаблонной функции генерации кнопок
            index = texts.index(message.text)
            table = nextStep[index]
            lastTable = lastStep[index]
            print(table)
            if table == "<-":
                data = getData(lastTable)
                menu_select_step(message, data)
            else:
                data = getData(table)
                menu_select_step(message, data)
    except Exception as e:
        bot.reply_to(message, 'Error 404')
        start(message)

#Обычная функция генерации кнопок, ничего примечательного
def menu_select_step(message, data):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)  # переменная вызывает клавиатуру
    messageList = []
    for item in data:
        itembtn = types.KeyboardButton(item[1])
        messageList.append(str(item[4]))
        markup.add(itembtn)
    itemBtnBack = types.KeyboardButton('В НАЧАЛО')
    markup.add(itemBtnBack)
    msg = bot.send_message(message.chat.id,
                           messageList[0],
                           reply_markup=markup)  # вызвать клаву
    bot.register_next_step_handler(msg, process_select_step, data)

#функция отвечает за вывод текста(далее изображений) инструкции
def print_instruction_step(message, instruction):
    bot.send_message(message.chat.id, instruction)
    data = getData('t01')
    final_menu_select_step(message, data)

#Последний шаг, генерируются кнопки для завершения работы (вопрос: помогло или нет?)
def final_menu_select_step(message, data):
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)  # переменная вызывает клавиатуру
    messageList = []
    for item in data:
        itembtn = types.KeyboardButton(item[1])
        messageList.append(str(item[2]))
        markup.add(itembtn)
    msg = bot.send_message(message.chat.id,
                           messageList[0],
                           reply_markup=markup)  # вызвать клаву
    bot.register_next_step_handler(msg, final_process_select_step, data)

#выводится тескт с дальнейшими указаниями если инструкция не помогла. (в дальнейшем здесь будет вызываться запись в БД)
def final_process_select_step(message, data):
    try:
        texts = []
        answers = []
        firstTable = 't1'
        for item in data:
            texts.append(item[1])
            answers.append(item[3])
        index = texts.index(message.text)
        bot.send_message(message.chat.id, answers[index])
        data = getData(firstTable)
        main_menu_select_step(message, data)
    except Exception as e:
        bot.reply_to(message, 'Error 405')
        start(message)


#Не знаю что это но без этого не работает
@bot.message_handler(func=lambda m: True)
def message(message):
        start(message)

if __name__ == '__main__':
    bot.polling(none_stop=True